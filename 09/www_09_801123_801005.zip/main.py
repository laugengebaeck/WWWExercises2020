from app import flask

# start server: python main.py

if __name__ == '__main__':
    flask.run(host="0.0.0.0")  # to be more safe us 127.0.0.1 or ::1
